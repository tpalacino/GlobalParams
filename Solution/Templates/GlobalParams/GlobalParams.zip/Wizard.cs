﻿using GlobalParams;
using Microsoft.VisualStudio.TemplateWizard;
using System.Collections.Generic;

namespace $safeprojectname$
{
	public class Wizard : WizardMPT
	{
	}
}
